

export default class ProductController
{

    getAllProducts(req,res){
        res.send("welcome to my api")
    }

    addProduct(req, res){}

    rateProduct(req,res){}

    getOneProduct(req,res){}

}